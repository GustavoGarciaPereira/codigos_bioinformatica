from Bio.Seq import Seq

Seq1 = 'AACCGGTT'
Seq2 = 'AACCGGTT'
Seq3 = 'TTCCAAGG'

if Seq1==Seq2:
    print("As variáveis SeqX e SeqY são iguais")
else:
    print("As variáveis SeqX e SeqY são diferentes")